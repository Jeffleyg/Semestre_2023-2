// Jeffley Garçon

public class App {
    public static void main(String[] args) {
        System.out.println("###              JOGOS DE CARTA          ###");
        System.out.println("----------Jeffley GARÇON <23111000111>---------");
        Baralho cheap = new Baralho();
        System.out.println("Baralho 1: ");
        System.out.println("\uD83D\uDE09");// smiles
        System.out.println(cheap);

        cheap.embaralhar();
        System.out.println("Baralho (2) de embaralhado:");
        System.out.println("\uD83D\uDE02"); // código de smile kkkkkkkk
        System.out.println(cheap);
        System.out.println("THE END");
    }
}
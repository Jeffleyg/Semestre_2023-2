public class Baralho {
    private Carta[] cartas;
    

    public Baralho() {
        cartas = new Carta[52];
        

        String[] naipes = {"Copas", "Espadas", "Ouros", "Paus"};
        String[] valores = {"Ás", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valete", "Dama", "Rei"};


        // loop para cria os 52 cartas do baralho
        int i = 0;
        for (String naipe : naipes) {
            for (String valor : valores) {
                // tratamento de Exception
                try {
                    cartas[i] = new Carta(valor, naipe);
                    i++;
                } catch (IllegalArgumentException e) {
                    System.err.println("FALHA AO CRIAR CARTA 404: " + e.getMessage());
                }
            }
        }
    }

   
public void embaralhar() {
    int n = cartas.length;
    int trato = 3500; // podemos trocar a embalhada e muda o valor do trato alias para trocar

    for (int i = 0; i < trato; i++) {
        for (int j = 0; j < n; j++) {
            int Trocamento = (i + j) % n;
            Carta tal = cartas[j];
            cartas[j] = cartas[Trocamento];
            cartas[Trocamento] = tal;
        }
    }
}
    @Override
    public String toString() {
        StringBuilder arranjo = new StringBuilder();
        // PARA REPRESENTA UMA SEQUENCIA DE CARACTERES MUTÁVEL

        for (Carta carta : cartas) {
            arranjo.append(carta.toString()).append("\n");
        }
        return arranjo.toString();
    }
}


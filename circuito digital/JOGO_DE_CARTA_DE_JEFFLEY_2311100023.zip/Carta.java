public class Carta {
    private String valor;
    private String naipe;

    public Carta(String valor, String naipe) throws IllegalArgumentException {
        if (!getValidValor(valor) || !getValidNaipe(naipe)) {
            throw new IllegalArgumentException("Valor ou naipe de carta inválido");
        }
        this.valor = valor;
        this.naipe = naipe;
    }

    private boolean getValidValor(String valor) {
        String[] valueValid = {"Ás", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valete", "Dama", "Rei"};
        for (String value : valueValid) {
            if (value.equals(valor)) {
                return true;
            }
        }
        return false;
    }

    private boolean getValidNaipe(String naipe) {
        String[] naipesValid = {"Copas", "Espadas", "Ouros", "Paus"};
        for (String suit : naipesValid) {
            if (suit.equals(naipe)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "[" + valor + " de " + naipe + "]";
    }
}


public class Agencia {
    private int numero;

    // METODOS
    public Agencia(int numero){
        this.numero = numero;
    }
    
    public int getnumero(){
        return numero;
    }

    public void setnumero(int numero){
        this.numero = numero;
    }


}
